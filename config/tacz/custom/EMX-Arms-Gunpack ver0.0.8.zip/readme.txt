[逆境重科军备]EMX-Arms GunsPack
随性创作，技术有限。该枪械包尚在制作中，非最终版，严禁私自分发。
该武器包在tacz群内的所有测试版本仅供群内学习交流，请勿外传！
如需宣传引用，请注明本枪械包作者：SF2403（b站ID：SF2403）

鸣谢：TacZ全体开发者
Mod本体链接(curseforge)：
https://www.curseforge.com/minecraft/mc-mods/timeless-and-classics-zero


//本包配件tag(可添加进自己的枪械包进行联动)：
	"emxarms:sight_emx_demo2",
	"emxarms:sight_emx_integer",
	"emxarms:grip_emx_double",
	"emxarms:grip_emx_assert",
	"emxarms:grip_emx_maxvalue",


以下为本包专属配件（如EMX内核收束组件等）！请自行决定是否添加。
	"emxarms:muzzle_emx_encapsulation",
	"emxarms:muzzle_emx_encapsulationse",